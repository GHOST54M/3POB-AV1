import java.util.ArrayList;
import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner ler = new Scanner(System.in);
    int op, i, n;
    
    ArrayList<Produtos> produtos = new ArrayList();
    ArrayList<itensCarrinho> carrinho = new ArrayList();
    
    
    Produtos produto = new Produtos(1001, "Picanha", 79);
        produtos.add(produto);
    Produtos produto1 = new Produtos(1002, "Arroz", 19);
        produtos.add(produto);
    Produtos produto2 = new Produtos(1003, "Farinha", 9);
        produtos.add(produto);
    
    n = produtos.size();

    System.out.printf("\nProdutos no estoque:\n");
    System.out.printf("\n    ID:   NOME:   PREÇO:\n");
    for (i=0; i<n; i++) {
     // System.out.printf("\n %s", produtos.get(i));
    }

do{
   System.out.printf("\n Digite a opção:\n");
   System.out.printf("\n 1 - Para adicionar ao carrinho");
   System.out.printf("\n 0 - Finalizar compra");
      op = scanner.nextLine();
  
  switch(op)
  {
    case 1: 
System.out.printf("\n Digite o ID do produto para adicioná-lo:");
      
    break;
  }
}while(op != 0);
    
    int n2 = carrinho.size();
    
    System.out.printf("\n Seu carrinho:\n");
    
    for (i=0; i<n2; i++) {
      System.out.printf("\n %s", carrinho.get(i));
    }
    
}
}