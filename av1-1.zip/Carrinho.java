public class itensCarrinho {
  int idp;
  int quantp;
  
  public itensCarrinho( int idp, int quantp){
    this.idp = idp;
    this.quantp = quantp;
  }
  public int getIdp() {
    return idp;
  }
  public void setIdp(int idp) {
    this.idp = idp;
  }

  public int getQuantp() {
    return quantp;
  }
  public void setQuantp(String quantp) {
    this.quantp = quantp;
  }
}