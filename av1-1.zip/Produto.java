public class Produtos{
  int id;
  string nome;
  float valor;

  public Produtos( int id, string nome, float valor){
    this.valor = valor;
    this.nome = nome;
    this.id = id;
  }
  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
  
  public String getNome() {
    return nome;
  }
  public void setNome(String nome) {
    this.nome = nome;
  }
  
  public float getValor() {
    return valor;
  }
  public void setValor(float valor) {
    this.valor = valor;
  }
}